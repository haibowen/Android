package com.czy.zhiliao.Listener;

/**
 * Created by ZY on 2016/7/29.
 * RecycleView滑动到底部事件监听
 */
public interface OnSlideToTheBottomListener {

    void onSlideToTheBottom();

}
