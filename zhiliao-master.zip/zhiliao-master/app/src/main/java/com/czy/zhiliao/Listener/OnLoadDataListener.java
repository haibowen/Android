package com.czy.zhiliao.Listener;

/**
 * Created by ZY on 2016/7/26.
 * 加载事件监听
 */
public interface OnLoadDataListener {

    void onSuccess(Object object);

    void onFailure();

}
