package com.czy.zhiliao.Listener;

/**
 * Created by ZY on 2016/7/29.
 * 点击事件监听
 */
public interface OnItemClickListener {

    void OnItemClick(int position);

}
